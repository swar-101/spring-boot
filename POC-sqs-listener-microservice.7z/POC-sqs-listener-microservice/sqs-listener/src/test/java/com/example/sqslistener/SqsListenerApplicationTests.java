package com.example.sqslistener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqsListenerApplicationTests {

	@Test
	void contextLoads() {
	}

}
